package com.stackroute.restAPI1.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Movie {
    @Id
    private String movieId;
    private String movieName;
    private String directorName;

    public Movie() {
    }

    public Movie(String movieId, String movieName, String directorName) {
        this.movieId = movieId;
        this.movieName = movieName;
        this.directorName = directorName;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getDirectorName() {
        return directorName;
    }

    public void setDirectorName(String directorName) {
        this.directorName = directorName;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "movieId=" + movieId +
                ", movieName='" + movieName + '\'' +
                ", directorName='" + directorName + '\'' +
                '}';
    }
}
