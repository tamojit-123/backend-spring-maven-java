package com.stackroute.springBootDemoOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemoOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoOneApplication.class, args);
	}

}
